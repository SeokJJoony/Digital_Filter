#pragma once

class Fourier
{
public:
	int	m_Data;
	double *m_FInData1,*m_FInData2, *m_OutData1,*m_OutData2;

public:
	Fourier(void);
	~Fourier(void);

	void	Fourier_Fun(void);
};
