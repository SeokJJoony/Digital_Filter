#include "stdafx.h"
#include "Draw_XY.h"

Draw_XY::Draw_XY(void)
{
}

Draw_XY::~Draw_XY(void)
{
}

//ȭ�鿡 Ʋ�� �׸��� �Լ�
void Draw_XY::Disp_Coor(CDC* pDC)
{
	pDC->MoveTo(TimeX1_Start, TimeY1_Start);
	pDC->LineTo(TimeX1_Start, TimeY1_End);
	pDC->MoveTo(TimeX1_Start, TimeY1_Start);
	pDC->LineTo(TimeX1_End, TimeY1_Start);
	pDC->MoveTo(TimeX1_Start, TimeY1);
	pDC->LineTo(TimeX1_End, TimeY1);
	pDC->MoveTo(TimeX1_End, TimeY1_Start);
	pDC->LineTo(TimeX1_End, TimeY1_End);

	pDC->MoveTo(TimeX2_Start, TimeY2_Start);
	pDC->LineTo(TimeX2_End, TimeY2_Start);
	pDC->MoveTo(TimeX2_Start, TimeY2_Start);
	pDC->LineTo(TimeX2_Start, TimeY2_End);
	pDC->MoveTo(TimeX2_Start, TimeY2);
	pDC->LineTo(TimeX2_End, TimeY2);
	pDC->MoveTo(TimeX2_End, TimeY2_Start);
	pDC->LineTo(TimeX2_End, TimeY2_End);

	pDC->MoveTo(TimeX3_Start, TimeY3_Start);
	pDC->LineTo(TimeX3_End, TimeY3_Start);
	pDC->MoveTo(TimeX3_Start, TimeY3_Start);
	pDC->LineTo(TimeX3_Start, TimeY3_End);
	pDC->MoveTo(TimeX3_Start, TimeY3);
	pDC->LineTo(TimeX3_End, TimeY3);
	pDC->MoveTo(TimeX3_End, TimeY3_Start);
	pDC->LineTo(TimeX3_End, TimeY3_End);

	pDC->MoveTo(FreqX1_Start, FreqY1_Start);
	pDC->LineTo(FreqX1_End, FreqY1_Start);
	pDC->MoveTo(FreqX1_Start, FreqY1);
	pDC->LineTo(FreqX1_End, FreqY1);
	pDC->MoveTo(FreqX1_End, FreqY1_Start);
	pDC->LineTo(FreqX1_End, FreqY1_End);

	pDC->MoveTo(FreqX2_Start, FreqY2_Start);
	pDC->LineTo(FreqX2_End, FreqY2_Start);
	pDC->MoveTo(FreqX2_Start, FreqY2);
	pDC->LineTo(FreqX2_End, FreqY2);
	pDC->MoveTo(FreqX2_End, FreqY2_Start);
	pDC->LineTo(FreqX2_End, FreqY2_End);

	pDC->Rectangle(FreqX3_Start, FreqY3_Start, FreqX3_End, FreqY3_End);
	pDC->MoveTo(FreqX3_Start, FreqY3);
	pDC->LineTo(FreqX3_End, FreqY3);
}