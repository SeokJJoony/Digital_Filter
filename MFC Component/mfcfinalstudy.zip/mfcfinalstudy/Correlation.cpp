#include "StdAfx.h"
#include "Correlation.h"
#define NO_DATA1 600
#define NO_DATA2 600

Correlation::Correlation(void)
{
	No_Data1=No_Data2=600;
	for(int i=0;i<DeCon;i++)
	{
		m_InData1[i]=m_InData2[i]=m_OutData[i]=0;
	}
}


Correlation::~Correlation(void)
{
}

void Correlation::Cor_Function(void)
{   
	for(int k=0; k<NO_DATA1; k++)    
	{  
		m_OutData[k]=0;
		for(int n=0; n<NO_DATA2;n++)
		{
			m_OutData[k]+= m_InData1[n]*m_InData2[n-k];
		}
	} 
} 