#pragma once

#define DeCon 1024
class Correlation
{
public:
	int No_Data1,No_Data2;
public: 
	double m_InData1[DeCon];
	double m_InData2[DeCon];
	double m_OutData[DeCon];

public:
	Correlation(void);
	~Correlation(void);

	void Cor_Function(void);


};

