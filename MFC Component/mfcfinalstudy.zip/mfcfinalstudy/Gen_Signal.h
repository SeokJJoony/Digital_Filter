#pragma once
#define Array_No 2000
#define Pi 3.14
#define M 50
#include <math.h>

class Gen_Signal
{
public:
	Gen_Signal();
	Gen_Signal(int NO_DATA1,int NO_DATA2);
	~Gen_Signal(void);
	void GenSignal();
public:
	CString MenuFlag1;
	int m_FreQu1, NO_DATA1;
	double GenData1[Array_No];
public:
	int m_WhiteNo;
};

