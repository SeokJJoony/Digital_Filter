#pragma once
#define pi 3.14
#define No_Total 1024
#include <math.h>

class Gen_Signal
{
public:
	Gen_Signal(void);
	~Gen_Signal(void);
public:
	CString m_string;
	int Data_No,m_FreQ;
	double Sin_Data[No_Total],Cos_Data[No_Total];
	void Signal_Data();
};

