#pragma once

#define m_FreQu 1
#define Pi 3.141592
#define FSNo 1024
#include <math.h>

class Fourierseries
{
public:
	double m_InFSData[FSNo],m_OutFSData[FSNo];
public:
	Fourierseries(void);
	~Fourierseries(void);
public:
	void Fourierseries::FourieCn();
	void Fourierseries::FourieCal();
	public:
		int m_CoeNo;
};

