#include "StdAfx.h"
#include "Fourierseries.h"


Fourierseries::Fourierseries(void)
{
	m_CoeNo=1024;
}


Fourierseries::~Fourierseries(void)
{
}

void Fourierseries::FourieCn()
{
	
	for(int i=0;i<m_CoeNo;i++)
	{
		m_InFSData[i]=0;
	} 
	m_InFSData[10]=1;
}

void Fourierseries::FourieCal()
{
	for(int n=0;n<1024;n++)
	{
		m_OutFSData[n]=0;
		for(int i =1;i<m_CoeNo;i++)
		{
			m_OutFSData[n]+=m_InFSData[i]*cos((2*Pi*i*m_FreQu/FSNo)*n);
			//m_OutFSData[n]+=m_InFSData[i]*cos(2*Pi*n*i*m_FreQu/FSNo);
		}
		
		 
		
	}
}
