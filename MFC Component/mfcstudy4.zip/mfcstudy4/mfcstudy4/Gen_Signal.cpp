#include "StdAfx.h"
#include "Gen_Signal.h"

Gen_Signal::Gen_Signal(void)
{
}
Gen_Signal::Gen_Signal(int NO_DATA1,int NO_DATA2)
{
	NO_DATA1=0,NO_DATA2=0;
}


Gen_Signal::~Gen_Signal(void)
{
}

void Gen_Signal::GenSignal()
{
	if(MenuFlag1=="Sin") 
	{
		for(int i=0; i<NO_DATA1; i++) 
		{
			GenData1[i]=sin((2*Pi*m_FreQu1/NO_DATA1)*i*M);
		} 
	}
	else if(MenuFlag1=="SinWhite") 
	{
		for(int i=0; i<NO_DATA1; i++) 
		{
			GenData1[i]=sin((2*Pi*m_FreQu1/NO_DATA1)*i*M)
			+(double(rand()%10))/m_WhiteNo;
		} 
	}
	else if(MenuFlag1=="Cos") 
	{
		for(int i=0; i<NO_DATA1; i++) 
		{
			GenData1[i]=cos((2*Pi*m_FreQu1/NO_DATA1)*i*M);
		} 
	}
	else if(MenuFlag1=="Unit") 
	{
		for(int i=0; i<NO_DATA1; i++) 
		{
			GenData1[i]=1;
		} 
	}
	else if(MenuFlag1=="Ramp") 
	{
		for(int i=0; i<NO_DATA1; i++) 
		{
			GenData1[i]=i/4;
		} 
	}
}