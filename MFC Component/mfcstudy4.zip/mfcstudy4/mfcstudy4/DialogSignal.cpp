// DialogSignal.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "mfcstudy4.h"
#include "DialogSignal.h"
#include "afxdialogex.h"


// CDialogSignal ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDialogSignal, CDialog)

CDialogSignal::CDialogSignal(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogSignal::IDD, pParent)
	, m_Sig1Name(_T(""))
	, m_Sig2Name(_T(""))
	, m_Sig1Fre(0)
	, m_Sig2Fre(0)
	, m_Sig1No(0)
	, m_Sig2No(0)
{

}

CDialogSignal::~CDialogSignal()
{
}

void CDialogSignal::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_CBString(pDX, IDC_COMBO1, m_Sig1Name);
	DDX_CBString(pDX, IDC_COMBO2, m_Sig2Name);
	DDX_Text(pDX, IDC_EDIT3, m_Sig1Fre);
	DDX_Text(pDX, IDC_EDIT4, m_Sig2Fre);
	DDX_Text(pDX, IDC_EDIT5, m_Sig1No);
	DDX_Text(pDX, IDC_EDIT6, m_Sig2No);
}


BEGIN_MESSAGE_MAP(CDialogSignal, CDialog)
END_MESSAGE_MAP()


// CDialogSignal �޽��� ó�����Դϴ�.
