#include "StdAfx.h"
#include "Disp_Signal.h"

#define M 100
#define Sample_T 1

Disp_Signal::Disp_Signal(void)
{
	for(int t=0; t<No_Total;t++)
	{
		Disp_Data[t]= 0;
	}
}


Disp_Signal::~Disp_Signal(void)
{
}

void Disp_Signal::Display_Signal(CDC* pDC,int start_x,int start_y)
{
	CPen pen(PS_SOLID,1,RGB(10,10,10));
	CPen *pOldPen = pDC->SelectObject(&pen);
	pDC->Rectangle(20,20,start_x,start_y+200);
	for(int t=0; t<No_Total;t+=Sample_T)
	{
		pDC->MoveTo(start_x+t,start_y);
		pDC->LineTo(start_x+t,start_y-Disp_Data[t]*M);
	}
	pDC->SelectObject(pOldPen);
}

void Disp_Signal::Display_Signal(CDC* pDC,CPoint CP)
{
	CPen pen(PS_SOLID,1,RGB(100,100,255));
	CPen* pOldPen=pDC->SelectObject(&pen);
	
	for(int t=0;t<No_Total;t++)
	{
		pDC->MoveTo(CP.x+t,CP.y);
		pDC->LineTo(CP.x+t,CP.y-Disp_Data[t]*M);
	}
	pDC->SelectObject(pOldPen);
}



