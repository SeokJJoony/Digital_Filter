#pragma once
#define Total_No 1024
#define Pi 3.14
#define M 50
#include <math.h>

class Gen_Signal
{
public:
	Gen_Signal();
	~Gen_Signal(void);
	void GenSignal();
public:
	CString MenuFlag;
	
public:
	int	Data_No;
	int m_Signal_Freq;

	double Sin_Signal[Total_No]; 
	double Cos_Signal[Total_No];
	double Sinc_Signal[Total_No];
	double WhiteNoise_Signal[Total_No];
};

