#include "StdAfx.h"
#include "Gen_Signal.h"

Gen_Signal::Gen_Signal(void)
{
}

Gen_Signal::~Gen_Signal(void)
{
}

void Gen_Signal::GenSignal()
{
	int	t;
	if(MenuFlag == "Sin"){
		m_Signal_Freq=1;
		for(t=0; t<Data_No; t++)
			Sin_Signal[t] = sin((2*Pi*m_Signal_Freq/Data_No)*t);
	}
	else if(MenuFlag== "Cos") {
		for(t=0; t<Data_No ; t++)
			Cos_Signal[t] = cos((2*Pi*m_Signal_Freq/Data_No)*t);
	}
	else if(MenuFlag== "Sinc"){
		for(int i=0; i<Data_No; i++)
			Sinc_Signal[i] = sin((Pi*i*m_Signal_Freq)/Data_No)/((Pi*i)/Data_No);

		Sinc_Signal[0] = Sinc_Signal[1];
	}
	else if(MenuFlag== "White Noise"){
		int RandNo;
		for(int i=0; i<Data_No; i++){
			RandNo = rand()%100-50;
			WhiteNoise_Signal[i] = double(RandNo)/50;
		}
	}
	
}