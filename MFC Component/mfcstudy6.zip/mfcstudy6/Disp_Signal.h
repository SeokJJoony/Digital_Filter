#pragma once
#define No_Total 1024
class Disp_Signal
{
public:
	Disp_Signal(void);
	~Disp_Signal(void);
	void Display_Signal(CDC* pDC,int start_x,int start_y);
	void Display_Signal(CDC* pDC,CPoint CP);
public:
	double Disp_Data[No_Total];

};

