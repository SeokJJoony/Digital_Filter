#include "StdAfx.h"
#include "Fourier.h"
#include <math.h>
#define	Total_No	1024
#define Pi 3.14159
Fourier::Fourier(void)
{
	m_FInData1=new double[Total_No];
	m_FInData2=new double[Total_No];
	m_OutData1=new double[Total_No];
	m_OutData2=new double[Total_No];
	for(int i=0; i<Total_No; i++)
	{
		m_FInData1[i]=m_OutData1[i]=m_FInData2[i]=m_OutData2[i]=0;
	}
}

Fourier::~Fourier(void)
{
	delete []m_FInData1;
	delete []m_FInData2;
	delete []m_OutData1;
	delete []m_OutData2;
}
void	Fourier::Fourier_Fun(void)
{
	double m_Real1, m_Image1,m_Real2, m_Image2;
	double	T_Real1, T_Image1,T_Real2, T_Image2;
	for(int fre=0; fre<m_Data; fre++)	//�� ���̵�
	{
		T_Real1=T_Image1=0;
		for(int n=0; n<m_Data; n++)
		{
			m_Real1=m_FInData1[n]*cos(2*Pi*fre*n/m_Data);
			m_Image1=m_FInData1[n]*sin(2*Pi*fre*n/m_Data);
			T_Real1+=m_Real1;
			T_Image1+=m_Image1;
		}
		m_OutData1[fre]= sqrt(T_Real1*T_Real1+T_Image1*T_Image1);
	}
	for(int fre=0; fre<m_Data; fre++)	//�� ���̵�
	{
		T_Real2=T_Image2=0;
		for(int n=0; n<m_Data; n++)
		{
			m_Real2=m_FInData2[n]*cos(2*Pi*fre*n/m_Data);
			m_Image2=m_FInData2[n]*sin(2*Pi*fre*n/m_Data);
			T_Real2+=m_Real2;
			T_Image2+=m_Image2;
		}
		m_OutData2[fre]= sqrt(T_Real2*T_Real2+T_Image2*T_Image2);
	}
}
